#engine v8

#feature-id    BroadbandPaletteBlender : PhotonDumpsterFire > BroadbandPaletteBlender
#feature-icon  BroadbandPaletteBlender.svg
#feature-info  Linear broadband finishing pipeline. Continuum subtraction on linear data, per-channel stretch, LRGB combination, Ha blend.

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

// =========================================================================
// BroadbandPaletteBlender v2.0
// PhotonDumpsterFire Script Suite
// Copyright 2026 Brannon Quel
//
// Linear workflow: input linear pre-processed mono channels.
// Pipeline: continuum subtraction -> stretch all -> RGB combine ->
//           LRGB combine -> Ha blend -> SCNR -> saturation.
// =========================================================================

var SCRIPT_VERSION  = "2.0";
var SCRIPT_TITLE    = "Broadband Palette Blender";
var LEFT_COL_W      = 360;
var PREVIEW_MIN_W   = 650;
var PREVIEW_MIN_H   = 450;

// ── Default parameters ────────────────────────────────────────────────────
var DEFAULT_PARAMS = {
   haId:          "",
   lId:           "",
   rId:           "",
   gId:           "",
   bId:           "",
   // Continuum subtraction
   doHa:          false,
   csAuto:        true,
   csManual:      0.85,
   keepEmission:  false,

   // LRGB
   doLRGB:        true,
   lWeight:       0.75,
   lumMask:       false,
   // Ha blend
   haBlendFormula: 0,   // 0=Natural 1=Aggressive 2=StarProtect 3=Screen
   haBlendAmount: 0.50,
   // Finishing
   doSCNR:        true,
   scnrAmount:    0.50,
   doSat:         false,
   satAmount:     0.30,
   // Output
   previewScale:  4,
   outputSuffix:  "_BPB",
   closeWork:     true
};

var params = {};
for (var k in DEFAULT_PARAMS) params[k] = DEFAULT_PARAMS[k];

var SETTINGS_FILE = File.systemTempDirectory + "/BroadbandPaletteBlender_settings.json";

function saveSettings() {
   try {
      var f = new File; f.createForWriting(SETTINGS_FILE);
      f.outTextLn(JSON.stringify(params)); f.close();
   } catch(e) {}
}

function loadSettings() {
   try {
      if (!File.exists(SETTINGS_FILE)) return;
      var f = new File; f.openForReading(SETTINGS_FILE);
      var s = JSON.parse(f.read(f.size)); f.close();
      for (var k in s) if (params[k] !== undefined) params[k] = s[k];
   } catch(e) {}
}

loadSettings();

// ── Utility ───────────────────────────────────────────────────────────────
function windowById(id) {
   var wins = ImageWindow.windows;
   for (var i=0;i<wins.length;i++) if (wins[i].mainView.id===id) return wins[i];
   return null;
}
function closeById(id) { var w=windowById(id); if(w&&!w.isNull)w.forceClose(); }

function getMonoIds() {
   var ids=[""]; var wins=ImageWindow.windows;
   for (var i=0;i<wins.length;i++)
      if (!wins[i].mainView.image.isColor && wins[i].mainView.id.indexOf("_bpb_")<0)
         ids.push(wins[i].mainView.id);
   return ids;
}

function downsample(srcWin, newId, factor) {
   closeById(newId);
   var si=srcWin.mainView.image;
   var nw=new ImageWindow(si.width,si.height,1,si.bitsPerSample,si.isReal,false,newId);
   nw.mainView.beginProcess(UndoFlag.NoSwapFile);
   nw.mainView.image.assign(si);
   nw.mainView.endProcess();
   var ir=new IntegerResample; ir.zoomFactor=-factor; ir.downsamplingMode=IntegerResample.Average;
   ir.executeOn(nw.mainView); nw.hide(); return nw;
}

function cloneWin(srcWin, newId) {
   closeById(newId);
   var si=srcWin.mainView.image;
   var nw=new ImageWindow(si.width,si.height,1,si.bitsPerSample,si.isReal,false,newId);
   nw.mainView.beginProcess(UndoFlag.NoSwapFile);
   nw.mainView.image.assign(si);
   nw.mainView.endProcess();
   nw.hide(); return nw;
}

// ── Step 1: Continuum subtraction (linear) ────────────────────────────────
function bpb_continuumSubtract(haWin, rWin, autoRatio, manualRatio, emId) {
   var ratio = manualRatio;
   if (autoRatio) {
      console.writeln("  Computing photometric continuum ratio...");
      var haImg=haWin.mainView.image, rImg=rWin.mainView.image;
      var step=Math.max(1,Math.floor(Math.sqrt((rImg.width*rImg.height)/40000)));
      var rVals=[];
      for (var y=0;y<rImg.height;y+=step) for (var x=0;x<rImg.width;x+=step) {
         var rv=rImg.sample(x,y,0); if(isFinite(rv)&&rv>0) rVals.push(rv);
      }
      rVals.sort(function(a,b){return a-b;});
      var thresh=rVals[Math.floor(0.75*rVals.length)]||0.05;
      var ratios=[];
      for (var y2=0;y2<rImg.height;y2+=step) for (var x2=0;x2<rImg.width;x2+=step) {
         var rv2=rImg.sample(x2,y2,0); var hv2=haImg.sample(x2,y2,0);
         if (rv2>thresh&&isFinite(hv2)&&hv2>0&&hv2/rv2<2.0) ratios.push(hv2/rv2);
      }
      ratios.sort(function(a,b){return a-b;});
      if (ratios.length>20) {
         // Use 30th percentile -- below median to avoid nebula/core contamination
         // Cap at 0.85 to preserve enough emission residual for blending
         ratio=ratios[Math.floor(0.30*ratios.length)];
         ratio=Math.max(0.05,Math.min(0.85,ratio));
         console.writeln("    Auto ratio (30th pct): " + ratio.toFixed(4));
      } else {
         console.warningln("    Insufficient samples -- using manual: " + ratio.toFixed(4));
      }
   } else {
      console.writeln("  Continuum subtraction: manual ratio=" + ratio.toFixed(4));
   }
   closeById(emId);
   var pm=new PixelMath;
   pm.useSingleExpression=true;
   pm.expression="max(0,"+haWin.mainView.id+"-"+ratio.toFixed(6)+"*"+rWin.mainView.id+")";
   pm.generateOutput=true; pm.rescale=false; pm.truncate=true;
   pm.createNewImage=true; pm.showNewImage=false;
   pm.newImageId=emId; pm.newImageWidth=0; pm.newImageHeight=0;
   pm.newImageColorSpace=PixelMath.Gray; pm.newImageSampleFormat=PixelMath.SameAsTarget;
   pm.executeOn(haWin.mainView,false);
   var emWin=windowById(emId);
   if (!emWin) throw new Error("Emission image not created.");
   emWin.hide();
   console.writeln("  Emission image: " + emId + "  (ratio=" + ratio.toFixed(4) + ")");
   return ratio;
}

// ── Step 2: Stretch a single channel window ───────────────────────────────
// MAS for full-size images; HT auto-stretch fallback for small preview images
// (MAS requires at least 512px on the shorter dimension to avoid scale warnings)
function bpb_stretch(win) {
   var img = win.mainView.image;
   var minDim = Math.min(img.width, img.height);
   console.writeln("    stretch size: " + img.width + "x" + img.height + "  minDim=" + minDim + "  using=" + (minDim >= 512 ? "MAS" : "HT"));
   if (minDim >= 512) {
      var mas = new MultiscaleAdaptiveStretch;
      mas.targetBackground = 0.20;
      mas.shadowsClipping  = -2.8;
      mas.smallScaleMask   = true;
      mas.largeScaleMask   = true;
      mas.iterations       = 48;
      mas.colorSaturation  = 1.0;
      mas.executeOn(win.mainView, false);
   } else {
      // HT auto-stretch fallback for small images (preview downsample)
      var isColor = img.numberOfChannels >= 3;
      var nc = Math.min(img.numberOfChannels, 3);
      var rows = [];
      for (var ch = 0; ch < nc; ch++) {
         img.selectedChannel = ch;
         var med = img.median();
         var mad = img.MAD() * 1.4826;
         img.resetSelections();
         if (mad < 1e-10) mad = 1e-10;
         var shadows  = Math.max(0, med - 2.8 * mad);
         var range    = med - shadows;
         var midtones = (range > 0)
            ? Math.max(0.001, Math.min(0.999, (0.20 * range) / ((2*0.20 - 1)*range - 0.20)))
            : 0.5;
         rows.push([shadows, midtones, 1.0, 0.0, 1.0]);
      }
      var idRow = [0, 0.5, 1.0, 0.0, 1.0];
      var ht = new HistogramTransformation;
      if (!isColor || nc === 1) {
         ht.H = [idRow, idRow, idRow, rows[0], idRow];
      } else {
         ht.H = [rows[0], rows[1], rows[2], idRow, idRow];
      }
      ht.executeOn(win.mainView, false);
   }
}

// ── Step 3: ChannelCombination RGB ────────────────────────────────────────
function bpb_combineRGB(rId,gId,bId,outId) {
   console.writeln("  ChannelCombination: "+rId+"+"+gId+"+"+bId+" -> "+outId);
   closeById(outId);
   var cc=new ChannelCombination;
   cc.colorSpace=ChannelCombination.RGB;
   cc.channels=[[true,rId],[true,gId],[true,bId]];
   cc.executeGlobal();
   var wins=ImageWindow.windows; var rgbWin=null;
   for (var i=wins.length-1;i>=0;i--) {
      if (wins[i].mainView.image.isColor&&wins[i].mainView.id!==outId){rgbWin=wins[i];break;}
   }
   if (!rgbWin) throw new Error("ChannelCombination failed.");
   rgbWin.mainView.id=outId; return rgbWin;
}

// ── Step 4: LRGB combination ──────────────────────────────────────────────
function bpb_lrgbCombine(rgbWin,lId,useLumMask) {
   console.writeln("  LRGB combine: L="+lId);
   if (useLumMask) { var lw=windowById(lId); if(lw&&!lw.isNull){rgbWin.maskInverted=false;rgbWin.mask=lw;} }
   var cc=new ChannelCombination;
   cc.colorSpace=ChannelCombination.CIELab;
   cc.channels=[[true,lId],[false,""],[false,""]];
   cc.executeOn(rgbWin.mainView);
   if (useLumMask) rgbWin.removeMask();
}

// ── Step 5: Ha blend into RGB ─────────────────────────────────────────────
function bpb_blendHa(rgbWin,emId,formula,amount) {
   var a=amount.toFixed(6);
   var rg=rgbWin.mainView.id;
   var formulas=[
      // 0: Natural -- max(R, blend) + small G/B lift
      ["max("+rg+"[0],"+rg+"[0]*(1-"+a+")+"+emId+"*"+a+")",
       rg+"[1]+0.10*"+a+"*"+emId,
       rg+"[2]+0.03*"+a+"*"+emId],
      // 1: Aggressive red emission + slight G/B suppression
      ["min(1,"+rg+"[0]+"+a+"*"+emId+")",
       rg+"[1]*(1-0.10*"+a+")",
       rg+"[2]*(1-0.05*"+a+")"],
      // 2: Star color protection -- only adds where Ha > G,B
      ["max("+rg+"[0],"+rg+"[0]+"+a+"*"+emId+"*(1-max("+rg+"[1],"+rg+"[2])))",
       rg+"[1]",
       rg+"[2]"],
      // 3: Screen -- gentle on highlights
      ["1-(1-"+rg+"[0])*(1-"+a+"*"+emId+")",
       "1-(1-"+rg+"[1])*(1-0.08*"+a+"*"+emId+")",
       rg+"[2]"]
   ];
   var formulaNames=["Natural","Aggressive","StarProtect","Screen"];
   console.writeln("  Ha blend: formula="+formulaNames[formula]+"  amount="+amount.toFixed(3));
   var f=formulas[formula];
   var pm=new PixelMath;
   pm.useSingleExpression=false;
   pm.expression=f[0]; pm.expression1=f[1]; pm.expression2=f[2]; pm.expression3="";
   pm.generateOutput=true; pm.rescale=false; pm.truncate=true;
   pm.createNewImage=false; pm.showNewImage=false;
   pm.executeOn(rgbWin.mainView,false);
}

// ── Step 6: Finishing ─────────────────────────────────────────────────────
function bpb_scnr(win,amount) {
   console.writeln("  SCNR: amount="+amount.toFixed(2));
   var s=new SCNR; s.amount=amount; s.colorToRemove=SCNR.Green;
   s.protectionMethod=SCNR.AverageNeutral; s.executeOn(win.mainView,false);
}
function bpb_satBoost(win,amount) {
   console.writeln("  Saturation: "+amount.toFixed(2));
   var cc=new CurvesTransformation;
   cc.S=[[0,0],[0.5,Math.min(0.99,0.5+(amount-0.05)*0.35)],[1,1]];
   cc.executeOn(win.mainView,false);
}

// ── Main pipeline ─────────────────────────────────────────────────────────
function runPipeline(isPreview) {
   var p=params;
   var sf=isPreview?p.previewScale:1;
   var px=isPreview?"_bpb_pv":"_bpb_full";

   // IDs for working windows
   var wHa=px+"_Ha", wL=px+"_L", wR=px+"_R", wG=px+"_G", wB=px+"_B";
   var wEm=px+"_emission", wRGB=px+"_RGB";

   console.writeln(""); console.writeln("──────────────────────────────────────────");
   console.writeln(SCRIPT_TITLE+" v"+SCRIPT_VERSION+(isPreview?" [PREVIEW 1/"+sf+"]":" [FULL RUN]"));
   console.writeln("──────────────────────────────────────────");

   try {
      // Validate required inputs
      if (!windowById(p.rId)) throw new Error("R channel not found: "+p.rId);
      if (!windowById(p.gId)) throw new Error("G channel not found: "+p.gId);
      if (!windowById(p.bId)) throw new Error("B channel not found: "+p.bId);

      // ── Clone/downsample all channels ──────────────────────────────────
      console.writeln("  Preparing channels (1/"+sf+" scale)...");
      var rWin = isPreview ? downsample(windowById(p.rId),wR,sf) : cloneWin(windowById(p.rId),wR);
      var gWin = isPreview ? downsample(windowById(p.gId),wG,sf) : cloneWin(windowById(p.gId),wG);
      var bWin = isPreview ? downsample(windowById(p.bId),wB,sf) : cloneWin(windowById(p.bId),wB);

      var lWin = null;
      if (p.doLRGB && p.lId !== "") {
         if (!windowById(p.lId)) throw new Error("L channel not found: "+p.lId);
         lWin = isPreview ? downsample(windowById(p.lId),wL,sf) : cloneWin(windowById(p.lId),wL);
      }

      var haWin=null, emWin=null;
      if (p.doHa && p.haId !== "") {
         if (!windowById(p.haId)) throw new Error("Ha channel not found: "+p.haId);
         haWin = isPreview ? downsample(windowById(p.haId),wHa,sf) : cloneWin(windowById(p.haId),wHa);
      }

      // ── Step 1: Continuum subtraction (linear) ─────────────────────────
      if (haWin) {
         console.writeln("--- Step 1: Continuum Subtraction (linear) ---");
         bpb_continuumSubtract(haWin,rWin,p.csAuto,p.csManual,wEm);
         emWin=windowById(wEm);
         closeById(wHa); // Ha source no longer needed
      }

      // ── Step 2: Stretch all channels ───────────────────────────────────
      console.writeln("--- Step 2: Stretch ---");
      console.writeln("  Stretching R...");  bpb_stretch(rWin);
      console.writeln("  Stretching G...");  bpb_stretch(gWin);
      console.writeln("  Stretching B...");  bpb_stretch(bWin);
      if (lWin) { console.writeln("  Stretching L..."); bpb_stretch(lWin); }
      if (emWin) {
         console.writeln("  Stretching Ha emission...");
         // Emission is low signal -- use more passes and lower target bg for faint signal
         bpb_stretch(emWin);
         if (p.keepEmission) {
            emWin.mainView.id="HaEmission_BPB"; emWin.show(); emWin.zoomToFit();
            console.writeln("  Emission image kept as: HaEmission_BPB");
            // Make a clone for blending so displayed emission is untouched
            closeById(wEm+"_blend");
            var emBlend=cloneWin(emWin,"_bpb_em_blend");
            wEm="_bpb_em_blend";
         }
      }

      // ── Step 3: ChannelCombination RGB ─────────────────────────────────
      console.writeln("--- Step 3: ChannelCombination RGB ---");
      var rgbWin=bpb_combineRGB(wR,wG,wB,wRGB);
      closeById(wR); closeById(wG); closeById(wB);

      // ── Step 4: LRGB combination ────────────────────────────────────────
      if (lWin) {
         console.writeln("--- Step 4: LRGB Combination ---");
         bpb_lrgbCombine(rgbWin,wL,p.lumMask);
         closeById(wL);
      }

      // ── Step 5: Ha blend ────────────────────────────────────────────────
      if (emWin && windowById(wEm)) {
         console.writeln("--- Step 5: Ha Blend ---");
         bpb_blendHa(rgbWin,wEm,p.haBlendFormula,p.haBlendAmount);
         if (!p.keepEmission) closeById(wEm);
         else closeById("_bpb_em_blend");
      }

      // ── Step 6: Finishing ────────────────────────────────────────────────
      if (p.doSCNR)  { console.writeln("--- Step 6a: SCNR ---");       bpb_scnr(rgbWin,p.scnrAmount); }
      if (p.doSat)   { console.writeln("--- Step 6b: Saturation ---");  bpb_satBoost(rgbWin,p.satAmount); }

      if (!isPreview) {
         var finalId="BPB_"+p.rId.replace(/_PCP$/,"").replace(/_/g,"")+p.outputSuffix;
         rgbWin.mainView.id=finalId;
         rgbWin.show(); rgbWin.zoomToFit();
         console.writeln(""); console.writeln("=== Complete: "+finalId+" ===");
         Console.show();
      }

      return rgbWin;

   } catch(e) {
      console.criticalln("Pipeline error: "+e.message);
      if (isPreview) Console.show();
      throw e;
   }
}

// ── Splash ────────────────────────────────────────────────────────────────
function printPDFSplash() {
   console.writeln("");
   console.writeln("\x1b[1;33m    ===  PhotonDumpsterFire  ===\x1b[0m");
   console.writeln("\x1b[0;36m    PixInsight Script Suite  |  v1.0\x1b[0m");
   console.writeln("");
   console.writeln("\x1b[0;33m       )  (    )    (  )   (   )      \x1b[0m");
   console.writeln("\x1b[0;33m     (   )(  ) ( )(  ) (  )(   ) (    \x1b[0m");
   console.writeln("\x1b[0;33m   )(  )( )( )(  )( )( )(  )(  )(  ) \x1b[0m");
   console.writeln("\x1b[0;33m  ( )( )( )( )( )( )( )( )( )( )( )( \x1b[0m");
   console.writeln("\x1b[0;31m )( )( )( )( )( )( )( )( )( )( )( )( \x1b[0m");
   console.writeln("\x1b[0;31m ( )( )( )( )( )( )( )( )( )( )( )( )\x1b[0m");
   console.writeln("\x1b[0;37m ___/\'\'\'\'\'\'\'\'\'\'\'\'\'\'\'\'\'\'\'\'\'\'\'\'\'\'\'\'\'\'\\___\x1b[0m");
   console.writeln("\x1b[0;37m |                                    |\x1b[0m");
   console.writeln("\x1b[0;37m +====================================+\x1b[0m");
   console.writeln("\x1b[0;37m |  PHOTONS      GRADIENTS     NOISE  |\x1b[0m");
   console.writeln("\x1b[0;37m |  HALOS        BANDING       TILT   |\x1b[0m");
   console.writeln("\x1b[0;37m |  CLOUDS       WIND          SEEING |\x1b[0m");
   console.writeln("\x1b[0;37m |  MOONLIGHT    VIGNETTING    COMA   |\x1b[0m");
   console.writeln("\x1b[0;37m |  AMP GLOW     SATELLITES    FLATS  |\x1b[0m");
   console.writeln("\x1b[0;37m |  GUIDING      DEW           FOCUS  |\x1b[0m");
   console.writeln("\x1b[0;37m +====================================+\x1b[0m");
   console.writeln("\x1b[0;36m  \\_/|                              |\\_/ \x1b[0m");
   console.writeln("\x1b[0;36m   o +------------------------------+ o  \x1b[0m");
   console.writeln("\x1b[0;36m  (_)                                (_) \x1b[0m");
   console.writeln("\x1b[0;36m  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  \x1b[0m");
   console.writeln("");
   console.writeln("\x1b[0;32m    ===  Everything is Fine  ===\x1b[0m");
   console.writeln("\x1b[0;33m    * * * * * * ( \u30c4 ) * * * * * *\x1b[0m");
   console.writeln("");
   console.writeln("\x1b[0;36m  -------------------------------------------\x1b[0m");
   console.writeln("\x1b[0;36m  GradientInspector | StretchInspector | ProcessContainerPlus\x1b[0m");
   console.writeln("\x1b[0;36m  NarrowbandPaletteBlender | IterativeStretch | BroadbandPaletteBlender\x1b[0m");
   console.writeln("\x1b[0;37m  Copyright 2026 Brannon Quel  |  PixInsight Script Suite\x1b[0m");
   console.writeln("");
}

// ── Preview ScrollBox ─────────────────────────────────────────────────────
const BPB_CROSS=13, BPB_HAND=28;

var BPBPreviewScrollBox = class extends ScrollBox {
   constructor(parent) {
      super(parent);
      this.bitmap=null; this.zoomFactor=1.0; this.minZoom=0.05; this.maxZoom=16.0;
      this.dragging=false; this.dragOrigin=new Point(0,0); this.dragScrollStart=new Point(0,0);
      this.onZoomChanged=null; this.autoScroll=true; this.tracking=true;
      this.cursor=new Cursor(BPB_CROSS);
      var self=this;
      this.onHorizontalScrollPosUpdated=function(){this.viewport.update();};
      this.onVerticalScrollPosUpdated=function(){this.viewport.update();};
      this.viewport.onResize=function(){self._updateScrollRange();};
      this.viewport.onMousePress=function(x,y,button){
         if((button&1)===0)return;
         self.dragging=true; self.dragOrigin=new Point(x,y);
         self.dragScrollStart=new Point(self.horizontalScrollPosition,self.verticalScrollPosition);
         this.cursor=new Cursor(BPB_HAND);
      };
      this.viewport.onMouseRelease=function(){self.dragging=false;this.cursor=new Cursor(BPB_CROSS);};
      this.viewport.onMouseMove=function(x,y){
         if(self.dragging){
            self.horizontalScrollPosition=self.dragScrollStart.x+(self.dragOrigin.x-x);
            self.verticalScrollPosition=self.dragScrollStart.y+(self.dragOrigin.y-y);
         }
      };
      this.viewport.onMouseWheel=function(x,y,delta){
         var oldZ=self.zoomFactor;
         var newZ=(delta>0)?Math.min(oldZ*1.25,self.maxZoom):Math.max(oldZ*0.8,self.minZoom);
         if(newZ===oldZ)return; self._zoomAt(newZ,x,y);
         if(self.onZoomChanged)self.onZoomChanged(self.zoomFactor);
      };
      this.viewport.onPaint=function(x0,y0,x1,y1){
         var g=new Graphics(this);
         g.fillRect(x0,y0,x1,y1,new Brush(0xFF080808));
         if(self.bitmap){
            var bw=Math.round(self.bitmap.width*self.zoomFactor);
            var bh=Math.round(self.bitmap.height*self.zoomFactor);
            var dx=(self.maxHorizontalScrollPosition>0)?-self.horizontalScrollPosition:Math.floor((this.width-bw)/2);
            var dy=(self.maxVerticalScrollPosition>0)?-self.verticalScrollPosition:Math.floor((this.height-bh)/2);
            g.drawScaledBitmap(new Rect(dx,dy,dx+bw,dy+bh),self.bitmap);
            g.pen=new Pen(0xff444444,0); g.drawRect(dx-1,dy-1,dx+bw,dy+bh);
         } else {
            g.pen=new Pen(0xFF334466); g.font=new Font("Helvetica",13);
            var msg="Click Preview / Refresh to render";
            g.drawText(Math.round((this.width-g.font.width(msg))/2),Math.round(this.height/2)+6,msg);
         }
         g.end();
      };
   }
   _updateScrollRange(){
      if(!this.bitmap){this.setHorizontalScrollRange(0,0);this.setVerticalScrollRange(0,0);}
      else{
         var bw=Math.round(this.bitmap.width*this.zoomFactor);
         var bh=Math.round(this.bitmap.height*this.zoomFactor);
         this.setHorizontalScrollRange(0,Math.max(0,bw-this.viewport.width));
         this.setVerticalScrollRange(0,Math.max(0,bh-this.viewport.height));
      }
      this.viewport.update();
   }
   _zoomAt(newZ,vx,vy){
      var ratio=newZ/this.zoomFactor; this.zoomFactor=newZ; this._updateScrollRange();
      this.horizontalScrollPosition=Math.max(0,(this.horizontalScrollPosition+vx)*ratio-vx);
      this.verticalScrollPosition=Math.max(0,(this.verticalScrollPosition+vy)*ratio-vy);
   }
   setBitmap(bmp){if(this.bitmap)this.bitmap.clear();this.bitmap=(bmp&&bmp.width>0)?bmp:null;this._updateScrollRange();}
   clearBitmap(){if(this.bitmap){this.bitmap.clear();this.bitmap=null;}this._updateScrollRange();}
   zoomIn(){var n=Math.min(this.zoomFactor*1.25,this.maxZoom);this._zoomAt(n,Math.floor(this.viewport.width/2),Math.floor(this.viewport.height/2));if(this.onZoomChanged)this.onZoomChanged(this.zoomFactor);}
   zoomOut(){var n=Math.max(this.zoomFactor*0.8,this.minZoom);this._zoomAt(n,Math.floor(this.viewport.width/2),Math.floor(this.viewport.height/2));if(this.onZoomChanged)this.onZoomChanged(this.zoomFactor);}
   zoom1to1(){this.zoomFactor=1.0;this.horizontalScrollPosition=0;this.verticalScrollPosition=0;this._updateScrollRange();if(this.onZoomChanged)this.onZoomChanged(this.zoomFactor);}
   zoomFit(){
      if(!this.bitmap)return;
      var z=Math.max(this.minZoom,Math.min(this.maxZoom,Math.min(this.viewport.width/this.bitmap.width,this.viewport.height/this.bitmap.height)));
      this.zoomFactor=z;this.horizontalScrollPosition=0;this.verticalScrollPosition=0;this._updateScrollRange();if(this.onZoomChanged)this.onZoomChanged(this.zoomFactor);
   }
};

// ── Dialog ────────────────────────────────────────────────────────────────
var BPBDialog = class extends Dialog {
   constructor() {
      super();
      var self=this;
      this.windowTitle=SCRIPT_TITLE+" v"+SCRIPT_VERSION;
      this.userResizable=true;
      var previewWin=null;

      function sectionLabel(text){
         var l=new Label; l.text=text; l.textAlignment=TextAlignment.Left|TextAlignment.VertCenter;
         l.styleSheet="font-weight:bold;color:#88aaff;margin-top:4px;"; return l;
      }
      function hRule(){
         var f=new Frame; f.styleSheet="background:#334455;border:none;min-height:1px;max-height:1px;margin:1px 0;"; return f;
      }
      function labeledRow(labelText,labelWidth,control){
         var l=new Label; l.text=labelText; l.textAlignment=TextAlignment.Right|TextAlignment.VertCenter;
         l.minWidth=labelWidth; l.maxWidth=labelWidth;
         var r=new HorizontalSizer; r.spacing=6; r.add(l); r.add(control,100); return r;
      }
      function makeChCombo(paramKey){
         var ids=getMonoIds(); var c=new ComboBox(self); c.editEnabled=false;
         for(var i=0;i<ids.length;i++)c.addItem(ids[i]);
         for(var j=0;j<c.numberOfItems;j++)if(c.itemText(j)===params[paramKey]){c.currentItem=j;break;}
         c.onItemSelected=(function(k,cb){return function(idx){params[k]=cb.itemText(idx);};})(paramKey,c);
         return c;
      }
      function makeChRow(lbl,paramKey,color){
         var l=new Label(self); l.text=lbl; l.minWidth=26; l.maxWidth=26;
         l.textAlignment=TextAlignment.Right|TextAlignment.VertCenter;
         l.styleSheet="font-weight:bold;color:"+color+";";
         var c=makeChCombo(paramKey);
         var r=new HorizontalSizer; r.spacing=6; r.add(l); r.add(c,100);
         return {row:r,combo:c};
      }

      // Header
      var hdr=new Label(self);
      hdr.text=SCRIPT_TITLE+" v"+SCRIPT_VERSION+"  |  Linear input  |  Preprocessed mono channels (no stretch)  |  MAS stretch applied automatically";
      hdr.textAlignment=TextAlignment.Left|TextAlignment.VertCenter;
      hdr.styleSheet="background:#1a2a3a;color:#88bbdd;font-weight:bold;padding:6px 10px;border-radius:3px;font-size:11px;";

      // ── Input channels ────────────────────────────────────────────────
      var haRow=makeChRow("Ha","haId","#cc6666");
      var lRow =makeChRow("L", "lId", "#aaaaaa");
      var rRow =makeChRow("R", "rId", "#cc3333");
      var gRow =makeChRow("G", "gId", "#33aa55");
      var bRow =makeChRow("B", "bId", "#3355cc");

      var chanControls=new VerticalSizer; chanControls.spacing=5;
      chanControls.add(haRow.row); chanControls.add(lRow.row);
      chanControls.add(rRow.row); chanControls.add(gRow.row); chanControls.add(bRow.row);

      // ── Stretch settings ──────────────────────────────────────────────


      // ── Ha continuum subtraction ──────────────────────────────────────
      var doHaCheck=new CheckBox(self);
      doHaCheck.text="Enable Ha Continuum + Blend"; doHaCheck.checked=params.doHa;
      doHaCheck.onCheck=function(checked){params.doHa=!!checked;haControls.visible=!!checked;self.adjustToContents();};

      var csAutoCheck=new CheckBox(self);
      csAutoCheck.text="Auto continuum ratio (photometric)"; csAutoCheck.checked=params.csAuto;
      csAutoCheck.onCheck=function(checked){params.csAuto=!!checked;csManualCtrl.enabled=!checked;};

      var csManualCtrl=new NumericControl(self);
      csManualCtrl.label.text="  Manual ratio:"; csManualCtrl.label.minWidth=130;
      csManualCtrl.setRange(0.01,1.0); csManualCtrl.slider.setRange(0,100);
      csManualCtrl.setPrecision(3); csManualCtrl.setValue(params.csManual);
      csManualCtrl.enabled=!params.csAuto;
      csManualCtrl.onValueUpdated=function(v){params.csManual=v;};

      var keepEmCheck=new CheckBox(self);
      keepEmCheck.text="Keep emission image for inspection"; keepEmCheck.checked=params.keepEmission;
      keepEmCheck.toolTip="Opens HaEmission_BPB after stretching so you can verify subtraction quality before blending.";
      keepEmCheck.onCheck=function(checked){params.keepEmission=!!checked;};

      var formulaCombo=new ComboBox(self);
      formulaCombo.addItem("Natural  (max blend + small G/B lift)");
      formulaCombo.addItem("Aggressive  (pure red + G/B suppress)");
      formulaCombo.addItem("Star Protect  (blend where Ha > G,B)");
      formulaCombo.addItem("Screen  (gentle on highlights)");
      formulaCombo.currentItem=params.haBlendFormula;
      formulaCombo.onItemSelected=function(idx){params.haBlendFormula=idx;};

      var haBlendCtrl=new NumericControl(self);
      haBlendCtrl.label.text="  Blend amount:"; haBlendCtrl.label.minWidth=130;
      haBlendCtrl.setRange(0.0,1.0); haBlendCtrl.slider.setRange(0,100);
      haBlendCtrl.setPrecision(2); haBlendCtrl.setValue(params.haBlendAmount);
      haBlendCtrl.onValueUpdated=function(v){params.haBlendAmount=v;};

      var haControls=new VerticalSizer; haControls.spacing=4;
      haControls.add(csAutoCheck); haControls.add(csManualCtrl); haControls.add(keepEmCheck);
      haControls.add(labeledRow("  Formula:",130,formulaCombo)); haControls.add(haBlendCtrl);
      haControls.visible=params.doHa;

      // ── LRGB settings ─────────────────────────────────────────────────
      var doLRGBCheck=new CheckBox(self);
      doLRGBCheck.text="LRGB Combination"; doLRGBCheck.checked=params.doLRGB;
      doLRGBCheck.onCheck=function(checked){params.doLRGB=!!checked;lumMaskCheck.enabled=!!checked;};

      var lumMaskCheck=new CheckBox(self);
      lumMaskCheck.text="Luminance mask (protect bright cores)"; lumMaskCheck.checked=params.lumMask;
      lumMaskCheck.enabled=params.doLRGB;
      lumMaskCheck.onCheck=function(checked){params.lumMask=!!checked;};

      // ── Finishing ─────────────────────────────────────────────────────
      var doSCNRCheck=new CheckBox(self);
      doSCNRCheck.text="SCNR green removal"; doSCNRCheck.checked=params.doSCNR;
      doSCNRCheck.onCheck=function(checked){params.doSCNR=!!checked;scnrCtrl.enabled=!!checked;};

      var scnrCtrl=new NumericControl(self);
      scnrCtrl.label.text="  Amount:"; scnrCtrl.label.minWidth=130;
      scnrCtrl.setRange(0.0,1.0); scnrCtrl.slider.setRange(0,100);
      scnrCtrl.setPrecision(2); scnrCtrl.setValue(params.scnrAmount);
      scnrCtrl.enabled=params.doSCNR;
      scnrCtrl.onValueUpdated=function(v){params.scnrAmount=v;};

      var doSatCheck=new CheckBox(self);
      doSatCheck.text="Saturation boost"; doSatCheck.checked=params.doSat;
      doSatCheck.onCheck=function(checked){params.doSat=!!checked;satCtrl.enabled=!!checked;};

      var satCtrl=new NumericControl(self);
      satCtrl.label.text="  Amount:"; satCtrl.label.minWidth=130;
      satCtrl.setRange(0.05,2.0); satCtrl.slider.setRange(0,200);
      satCtrl.setPrecision(2); satCtrl.setValue(params.satAmount);
      satCtrl.enabled=params.doSat;
      satCtrl.onValueUpdated=function(v){params.satAmount=v;};

      // ── Output ────────────────────────────────────────────────────────
      var suffixEdit=new Edit(self); suffixEdit.text=params.outputSuffix; suffixEdit.minWidth=80;
      suffixEdit.onEditCompleted=function(){params.outputSuffix=this.text.trim();};

      var closeWorkCheck=new CheckBox(self);
      closeWorkCheck.text="Close intermediate working images"; closeWorkCheck.checked=params.closeWork;
      closeWorkCheck.onCheck=function(checked){params.closeWork=!!checked;};

      // ── Left panel layout ─────────────────────────────────────────────
      var leftSizer=new VerticalSizer; leftSizer.spacing=2;

      leftSizer.add(sectionLabel("Input Channels  (linear, not stretched)")); leftSizer.add(hRule());
      leftSizer.addSpacing(4); leftSizer.add(chanControls); leftSizer.addSpacing(6);



      leftSizer.add(sectionLabel("Ha Continuum Subtraction + Blend")); leftSizer.add(hRule());
      leftSizer.addSpacing(4); leftSizer.add(doHaCheck); leftSizer.add(haControls); leftSizer.addSpacing(6);

      leftSizer.add(sectionLabel("LRGB Combination")); leftSizer.add(hRule());
      leftSizer.addSpacing(4); leftSizer.add(doLRGBCheck); leftSizer.add(lumMaskCheck); leftSizer.addSpacing(6);

      leftSizer.add(sectionLabel("Finishing")); leftSizer.add(hRule());
      leftSizer.addSpacing(4);
      leftSizer.add(doSCNRCheck); leftSizer.add(scnrCtrl);
      leftSizer.addSpacing(4); leftSizer.add(doSatCheck); leftSizer.add(satCtrl); leftSizer.addSpacing(6);

      leftSizer.add(sectionLabel("Output")); leftSizer.add(hRule());
      leftSizer.addSpacing(4);
      leftSizer.add(labeledRow("Suffix:",50,suffixEdit)); leftSizer.addSpacing(2);
      leftSizer.add(closeWorkCheck); leftSizer.addStretch();

      var leftFrame=new Frame(self); leftFrame.setFixedWidth(LEFT_COL_W); leftFrame.sizer=leftSizer;

      // ── Preview ───────────────────────────────────────────────────────
      var previewScrollBox=new BPBPreviewScrollBox(self);
      previewScrollBox.setMinSize(PREVIEW_MIN_W,PREVIEW_MIN_H);

      var zoomLabel=new Label(self); zoomLabel.text="100%"; zoomLabel.minWidth=50;
      zoomLabel.textAlignment=TextAlignment.Left|TextAlignment.VertCenter;
      zoomLabel.styleSheet="color:#88aacc;font-family:monospace;";
      previewScrollBox.onZoomChanged=function(z){zoomLabel.text=Math.round(z*100)+"%";};

      var zInBtn=new ToolButton(self); zInBtn.icon=self.scaledResource(":/icons/zoom-in.png"); zInBtn.setFixedSize(24,24); zInBtn.toolTip="Zoom in"; zInBtn.onClick=function(){previewScrollBox.zoomIn();};
      var zOutBtn=new ToolButton(self); zOutBtn.icon=self.scaledResource(":/icons/zoom-out.png"); zOutBtn.setFixedSize(24,24); zOutBtn.toolTip="Zoom out"; zOutBtn.onClick=function(){previewScrollBox.zoomOut();};
      var zFitBtn=new ToolButton(self); zFitBtn.icon=self.scaledResource(":/icons/zoom-fit.png"); zFitBtn.setFixedSize(24,24); zFitBtn.toolTip="Fit"; zFitBtn.onClick=function(){previewScrollBox.zoomFit();};
      var z11Btn=new ToolButton(self); z11Btn.icon=self.scaledResource(":/icons/zoom-1-1.png"); z11Btn.setFixedSize(24,24); z11Btn.toolTip="1:1"; z11Btn.onClick=function(){previewScrollBox.zoom1to1();};

      var zoomRow=new HorizontalSizer; zoomRow.spacing=4;
      zoomRow.add(zInBtn); zoomRow.add(zOutBtn); zoomRow.add(zFitBtn); zoomRow.add(z11Btn);
      zoomRow.addSpacing(8); zoomRow.add(zoomLabel); zoomRow.addStretch();

      var scaleMap=[2,4,8];
      var scaleCombo=new ComboBox(self);
      scaleCombo.addItem("1/2  (best quality)"); scaleCombo.addItem("1/4  (recommended)"); scaleCombo.addItem("1/8  (fastest)");
      var si2=scaleMap.indexOf(params.previewScale); scaleCombo.currentItem=(si2>=0)?si2:1;
      scaleCombo.onItemSelected=function(idx){params.previewScale=scaleMap[idx];};

      var pvOptionsRow=new HorizontalSizer; pvOptionsRow.spacing=6;
      pvOptionsRow.add(labeledRow("Quality",50,scaleCombo)); pvOptionsRow.addStretch();

      var pvStatusLabel=new Label(self);
      pvStatusLabel.text="Click Preview / Refresh to render";
      pvStatusLabel.styleSheet="color:#668899;font-style:italic;";

      var pvBtn=new PushButton(self);
      pvBtn.text="  Preview / Refresh"; pvBtn.icon=self.scaledResource(":/icons/find.png");
      pvBtn.toolTip="Run full pipeline on downsampled copy.\nMouse wheel zooms, drag to pan.";
      pvBtn.onClick=function(){
         pvStatusLabel.text="Rendering..."; CoreApplication.processEvents();
         try {
            if(previewWin){try{previewWin.forceClose();}catch(e){}previewWin=null;}
            var resultWin=runPipeline(true);
            if(resultWin){
               previewWin=resultWin;
               previewScrollBox.setBitmap(previewWin.mainView.image.render());
               previewScrollBox.zoomFit();
               pvStatusLabel.text="1/"+params.previewScale+"  |  wheel=zoom  drag=pan";
            }
         } catch(e){pvStatusLabel.text="Error: "+e.message;}
      };

      var pvEmBtn=new PushButton(self);
      pvEmBtn.text="  Preview Emission";
      pvEmBtn.icon=self.scaledResource(":/icons/find.png");
      pvEmBtn.toolTip="Show the Ha emission image after continuum subtraction + stretch.\nVerify the ratio is correct before running the full blend.\nBright areas = Ha emission signal.  Dark background = clean subtraction.";
      pvEmBtn.onClick=function(){
         if (!params.doHa || params.haId==="") {
            pvStatusLabel.text="Enable Ha and select Ha image first."; return;
         }
         pvStatusLabel.text="Computing emission..."; CoreApplication.processEvents();
         var sf=params.previewScale;
         var wHa2="_bpb_pv_Ha2", wR2="_bpb_pv_R2", wEm2="_bpb_pv_em2";
         try {
            var haWin2=windowById(params.haId); var rWin2=windowById(params.rId);
            if (!haWin2) { pvStatusLabel.text="Ha image not found."; return; }
            if (!rWin2)  { pvStatusLabel.text="R image not found."; return; }
            var dHa2=downsample(haWin2,wHa2,sf); var dR2=downsample(rWin2,wR2,sf);
            bpb_continuumSubtract(dHa2,dR2,params.csAuto,params.csManual,wEm2);
            var emWin2=windowById(wEm2);
            if (emWin2) {
               bpb_stretch(emWin2);
               previewScrollBox.setBitmap(emWin2.mainView.image.render());
               previewScrollBox.zoomFit();
               pvStatusLabel.text="Emission preview  |  bright=Ha signal  dark=clean subtraction  |  adjust ratio if needed";
            }
            closeById(wHa2); closeById(wR2); closeById(wEm2);
         } catch(e2){ pvStatusLabel.text="Error: "+e2.message; closeById(wHa2); closeById(wR2); closeById(wEm2); }
      };

      var pvBtnRow=new HorizontalSizer; pvBtnRow.spacing=8;
      pvBtnRow.add(pvBtn); pvBtnRow.addSpacing(4); pvBtnRow.add(pvEmBtn);
      pvBtnRow.addStretch(); pvBtnRow.add(pvStatusLabel);

      var rightSizer=new VerticalSizer; rightSizer.spacing=6;
      rightSizer.add(sectionLabel("Preview")); rightSizer.add(hRule());
      rightSizer.addSpacing(2); rightSizer.add(previewScrollBox,100);
      rightSizer.addSpacing(4); rightSizer.add(zoomRow);
      rightSizer.addSpacing(2); rightSizer.add(pvOptionsRow); rightSizer.add(pvBtnRow);

      // ── Action buttons ────────────────────────────────────────────────
      var runBtn=new PushButton(self); runBtn.text="  Run Full Pipeline";
      runBtn.icon=self.scaledResource(":/icons/execute.png");
      runBtn.styleSheet="font-weight:bold;padding:4px 16px;";
      runBtn.onClick=function(){
         saveSettings();
         if(previewWin){try{previewWin.forceClose();}catch(e){}previewWin=null;}
         runPipeline(false);
      };

      var resetBtn=new PushButton(self); resetBtn.text="  Reset";
      resetBtn.icon=self.scaledResource(":/icons/reload.png");
      resetBtn.onClick=function(){
         for(var k in DEFAULT_PARAMS)params[k]=DEFAULT_PARAMS[k];

         csManualCtrl.setValue(params.csManual); haBlendCtrl.setValue(params.haBlendAmount);
         scnrCtrl.setValue(params.scnrAmount); satCtrl.setValue(params.satAmount);
         suffixEdit.text=params.outputSuffix;
         doHaCheck.checked=params.doHa; haControls.visible=params.doHa;
         doLRGBCheck.checked=params.doLRGB; doSCNRCheck.checked=params.doSCNR;
         scnrCtrl.enabled=params.doSCNR; doSatCheck.checked=params.doSat; satCtrl.enabled=params.doSat;
      };

      var closeBtn=new PushButton(self); closeBtn.text="  Close";
      closeBtn.icon=self.scaledResource(":/icons/close.png");
      closeBtn.onClick=function(){saveSettings();if(previewWin){try{previewWin.forceClose();}catch(e){}}self.cancel();};

      var footerLabel=new Label(self);
      footerLabel.text=SCRIPT_TITLE+" v"+SCRIPT_VERSION+"  |  Copyright 2026 Brannon Quel  |  Originals never modified.";
      footerLabel.styleSheet="color:#445566;font-style:italic;font-size:10px;";

      var actionRow=new HorizontalSizer; actionRow.spacing=8;
      actionRow.add(runBtn); actionRow.addStretch(); actionRow.add(resetBtn); actionRow.add(closeBtn);

      var colSizer=new HorizontalSizer; colSizer.spacing=8;
      colSizer.add(leftFrame); colSizer.add(rightSizer,100);

      this.sizer=new VerticalSizer; this.sizer.margin=8; this.sizer.spacing=6;
      this.sizer.add(hdr); this.sizer.addSpacing(4); this.sizer.add(colSizer,100);
      this.sizer.addSpacing(4); this.sizer.add(actionRow); this.sizer.add(footerLabel);
      this.adjustToContents();
   }
};

function main() {
   printPDFSplash();
   if (ImageWindow.windows.length===0) {
      new MessageBox("No images open.",SCRIPT_TITLE,StdIcon.Error,StdButton.Ok).execute(); return;
   }
   var dlg=new BPBDialog(); dlg.execute();
}

main();
