#engine v8
// BatchCrop.js
// PixInsight Script - Batch Crop
//
// Displays a visual preview of a reference image. Draw a crop rectangle,
// then press Enter or click Apply to crop all open ImageWindows to the
// same region. Requires all images to be star-aligned (same dimensions).
//
// Part of the PhotonDumpsterFire PixInsight Script Suite
// Copyright 2026 Brannon Quel

#feature-id    BatchCrop : PhotonDumpsterFire > BatchCrop
#feature-icon  BatchCrop.svg
#feature-info  Visually draw a crop region on a reference image and apply it to all open images.

var SCRIPT_VERSION = "1.2";
var SCRIPT_TITLE   = "Batch Crop";

// ============================================================
// printSplash
// ============================================================
function printSplash() {
   console.writeln( "" );
   console.writeln( "\x1b[1;33m    ===  PhotonDumpsterFire  ===\x1b[0m" );
   console.writeln( "\x1b[0;36m    PixInsight Script Suite  |  v1.0\x1b[0m" );
   console.writeln( "" );
   console.writeln( "\x1b[0;33m       )  (    )    (  )   (   )      \x1b[0m" );
   console.writeln( "\x1b[0;33m     (   )(  ) ( )(  ) (  )(   ) (    \x1b[0m" );
   console.writeln( "\x1b[0;33m   )(  )( )( )(  )( )( )(  )(  )(  ) \x1b[0m" );
   console.writeln( "\x1b[0;33m  ( )( )( )( )( )( )( )( )( )( )( )( \x1b[0m" );
   console.writeln( "\x1b[0;31m )( )( )( )( )( )( )( )( )( )( )( )( \x1b[0m" );
   console.writeln( "\x1b[0;31m ( )( )( )( )( )( )( )( )( )( )( )( )\x1b[0m" );
   console.writeln( "\x1b[0;37m ___/\\'\\'\\'\\'\\'\\'\\'\\'\\'\\'\\'\\'\\'\\'\\'\\'\\'\\'\\'\\'\\'\\'\\'\\'\\'\\'\\'\\'\\'\\\\___\x1b[0m" );
   console.writeln( "\x1b[0;37m |                                    |\x1b[0m" );
   console.writeln( "\x1b[0;37m +====================================+\x1b[0m" );
   console.writeln( "\x1b[0;37m |  PHOTONS      GRADIENTS     NOISE  |\x1b[0m" );
   console.writeln( "\x1b[0;37m |  HALOS        BANDING       TILT   |\x1b[0m" );
   console.writeln( "\x1b[0;37m |  CLOUDS       WIND          SEEING |\x1b[0m" );
   console.writeln( "\x1b[0;37m |  MOONLIGHT    VIGNETTING    COMA   |\x1b[0m" );
   console.writeln( "\x1b[0;37m |  AMP GLOW     SATELLITES    FLATS  |\x1b[0m" );
   console.writeln( "\x1b[0;37m |  GUIDING      DEW           FOCUS  |\x1b[0m" );
   console.writeln( "\x1b[0;37m +====================================+\x1b[0m" );
   console.writeln( "\x1b[0;36m  \\_/|                              |\\_/ \x1b[0m" );
   console.writeln( "\x1b[0;36m   o +------------------------------+ o  \x1b[0m" );
   console.writeln( "\x1b[0;36m  (_)                                (_) \x1b[0m" );
   console.writeln( "\x1b[0;36m  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  \x1b[0m" );
   console.writeln( "" );
   console.writeln( "\x1b[0;32m    ===  Everything is Fine  ===\x1b[0m" );
   console.writeln( "\x1b[0;33m    * * * * * * ( \u30c4 ) * * * * * *\x1b[0m" );
   console.writeln( "" );
   console.writeln( "\x1b[0;36m  -------------------------------------------\x1b[0m" );
   console.writeln( "\x1b[0;36m  GradientInspector | StretchInspector | ProcessContainerPlus\x1b[0m" );
   console.writeln( "\x1b[0;36m  NarrowbandPaletteBlender | IterativeStretch | BroadbandPaletteBlender\x1b[0m" );
   console.writeln( "\x1b[0;37m  Copyright 2026 Brannon Quel  |  PixInsight Script Suite\x1b[0m" );
   console.writeln( "" );
}

// ============================================================
// CropPreviewControl
// ============================================================
var CropPreviewControl = class CropPreviewControl extends ScrollBox {
   constructor( parent ) {
      super( parent );

      this.autoScroll   = false;
      this.tracking     = true;

      this.sourceBitmap  = null;
      this.displayBitmap = null;

      this.imgWidth  = 0;
      this.imgHeight = 0;
      this.scale     = 1.0;

      function normalizeAnglePi( a ) {
         while ( a >  Math.PI ) a -= 2*Math.PI;
         while ( a < -Math.PI ) a += 2*Math.PI;
         return a;
      }
      this.dragAnchorX           = 0;
      this.dragAnchorY           = 0;
      this.dragSelSnapshot       = null;
      this.angle                 = 0.0;
      this.dragAngleStart        = 0.0;
      this.rotateCenterX         = 0.0;
      this.rotateCenterY         = 0.0;
      this.rotateStartMouseAngle = 0.0;
      this.rotateStartImageAngle = 0.0;
      this.stfEnabled    = false;
      this.stfBitmap     = null;
      this.linearBitmap  = null;
      this.scaleX = 1.0;
      this.scaleY = 1.0;
      this.viewX  = 0;
      this.viewY  = 0;
      this.viewW  = 0;
      this.viewH  = 0;

      this.onSelectionChanged = null;

      var self = this;

      this.computeSTF = function( imageWindow ) {
         try {
            var srcImg = imageWindow.mainView.image;

            // Clone full image
            var tw = new ImageWindow(
               srcImg.width, srcImg.height,
               srcImg.numberOfChannels, srcImg.bitsPerSample,
               srcImg.isReal, srcImg.isColor, "_batchcrop_stf"
            );
            tw.mainView.beginProcess( UndoFlag.NoSwapFile );
            tw.mainView.image.assign( srcImg );
            tw.mainView.endProcess();

            // Compute STF parameters on full-res image BEFORE downsampling
            function batchMTF( m, x ) {
               if ( x <= 0 ) return 0; if ( x >= 1 ) return 1;
               var d = (2*m-1)*x - m;
               return (Math.abs(d) < 1e-10) ? 0.5 : Math.max(0, Math.min(1, (m-1)*x/d));
            }
            var img  = tw.mainView.image;
            var nc   = img.numberOfChannels;
            var rows = [];
            for ( var ch = 0; ch < nc; ch++ ) {
               img.selectedChannel = ch;
               var med = img.median();
               var mad = img.MAD() * 1.4826;
               img.resetSelections();
                  if ( mad < 1e-10 ) mad = 1e-10;
               var c0      = Math.max( 0, med - 2.8 * mad );
               var range   = Math.max( 1e-10, 1.0 - c0 );
               var normMed = (med - c0) / range;
               if ( normMed < 1e-10 ) normMed = 1e-10;
               var target = 0.25;
               var m = (target - 1) * normMed / ((2*target - 1)*normMed - target);
               m = Math.max(0.001, Math.min(0.999, m));
               rows.push( [ c0, m, 1.0, 0, 1 ] );
            }
            var idRow = [ 0, 0.5, 1, 0, 1 ];
            var HT = new HistogramTransformation;
            HT.H = (nc === 1)
               ? [ idRow, idRow, idRow, rows[0], idRow ]
               : [ rows[0], rows[1], rows[2], idRow, idRow ];
            HT.executeOn( tw.mainView, false );

            // NOW downsample for display speed
            var factor = Math.max( 1, Math.floor( Math.min(srcImg.width,srcImg.height) / 900 ) );
            if ( factor > 1 ) {
               var ir = new IntegerResample;
               ir.zoomFactor = -factor;
               ir.downsamplingMode = IntegerResample.Average;
               ir.executeOn( tw.mainView, false );
            }

            if ( self.stfBitmap ) self.stfBitmap.clear();
            self.stfBitmap = tw.mainView.image.render();
            tw.forceClose();
            self.viewport.update();
            console.writeln( "BatchCrop: STF applied: " +
               self.stfBitmap.width + "x" + self.stfBitmap.height );

         } catch( e ) {
            self.stfBitmap = null;
            console.warningln( "BatchCrop STF failed: " + e.message );
         }
      };

      this.setImage = function( imageWindow ) {
         var img = imageWindow.mainView.image;

         self.imgWidth  = img.width;
         self.imgHeight = img.height;
         self.sourceBitmap = imageWindow.mainView.image.render();

         self.selStart = null;
         self.selEnd   = null;
         self.stfBitmap    = null;
         self.linearBitmap = null;

         if ( self.stfEnabled ) {
            self.computeSTF( imageWindow );
         }

         self.relayout();
      };

      this.relayout = function() {
         self.displayBitmap = null;
         self.viewport.update();
      };

      this.viewport.onResize = function( wNew, hNew, wOld, hOld ) {
         self.displayBitmap = null;
         self.viewport.update();
      };

      this.viewport.onPaint = function( x0, y0, x1, y1 ) {
         var vw = this.width;
         var vh = this.height;
         var g  = new Graphics( this );
         g.antialiasing = false;
         g.fillRect( 0, 0, vw, vh, new Brush( 0xff1a1a1a ) );

         // Pick bitmap -- STF if enabled, otherwise linear source
         var bmp = ( self.stfEnabled && self.stfBitmap ) ? self.stfBitmap : self.sourceBitmap;

         if ( bmp && bmp.width > 0 && self.imgWidth > 0 ) {
            // Scale to fit viewport, never upscale
            var sc   = Math.min( vw / bmp.width, vh / bmp.height, 1.0 );
            var dw   = Math.max( 1, Math.round( bmp.width  * sc ) );
            var dh   = Math.max( 1, Math.round( bmp.height * sc ) );
            var ox   = Math.round( (vw - dw) / 2 );
            var oy   = Math.round( (vh - dh) / 2 );

            // Store for coordinate mapping
            self.viewX  = ox;
            self.viewY  = oy;
            self.viewW  = dw;
            self.viewH  = dh;
            self.scaleX = self.imgWidth  / dw;
            self.scaleY = self.imgHeight / dh;

            // Render fresh -- no caching, no stale state possible
            var scaledBmp = bmp.scaledTo( dw, dh );
            g.drawBitmap( ox, oy, scaledBmp );

            // Draw selection overlay
            if ( self.selStart && self.selEnd ) {
               var rx0 = Math.min( self.selStart.x, self.selEnd.x );
               var ry0 = Math.min( self.selStart.y, self.selEnd.y );
               var rx1 = Math.max( self.selStart.x, self.selEnd.x );
               var ry1 = Math.max( self.selStart.y, self.selEnd.y );

               // Draw rotated box by transforming corners explicitly
               var selCX = ox + (rx0 + rx1) / 2;
               var selCY = oy + (ry0 + ry1) / 2;
               var hW    = (rx1 - rx0) / 2;
               var hH    = (ry1 - ry0) / 2;
               var ca    = Math.cos(self.angle);
               var sa    = Math.sin(self.angle);

               function rotPt( lx, ly ) {
                  return [ selCX + lx*ca - ly*sa, selCY + lx*sa + ly*ca ];
               }

               var tl = rotPt(-hW,-hH), tr = rotPt(hW,-hH);
               var bl = rotPt(-hW, hH), br = rotPt(hW, hH);
               var tm = rotPt(0,-hH),   bm = rotPt(0, hH);
               var ml = rotPt(-hW,0),   mr = rotPt(hW, 0);
               // Rotate handle
               var rh = rotPt(0,-hH-20);
               var rs = rotPt(0,-hH-2);

               // Box border
               g.pen   = new Pen( 0xffff4400, 2 );
               g.brush = new Brush( 0x00000000 );
               g.drawLine(tl[0],tl[1],tr[0],tr[1]);
               g.drawLine(tr[0],tr[1],br[0],br[1]);
               g.drawLine(br[0],br[1],bl[0],bl[1]);
               g.drawLine(bl[0],bl[1],tl[0],tl[1]);

               // Corner + edge handles
               var hs = 7;
               g.pen   = new Pen( 0xff884400, 1 );
               g.brush = new Brush( 0xffff6600 );
               var hpts = [tl,tr,bl,br,tm,bm,ml,mr];
               for ( var i=0; i<hpts.length; ++i )
                  g.drawRect(hpts[i][0]-hs/2,hpts[i][1]-hs/2,
                             hpts[i][0]+hs/2,hpts[i][1]+hs/2);

               // Rotate handle circle + stem
               g.pen   = new Pen( 0xff00aaff, 2 );
               g.brush = new Brush( 0xff004488 );
               g.drawEllipse(rh[0]-8,rh[1]-8,rh[0]+8,rh[1]+8);
               g.drawLine(rs[0],rs[1],rh[0],rh[1]);

               // Angle label
               if ( Math.abs(self.angle) > 0.001 ) {
                  g.pen  = new Pen( 0xff00aaff );
                  g.font = new Font("Helvetica", 10);
                  var deg = (normalizeAnglePi(self.angle) * 180 / Math.PI).toFixed(1) + "°";
                  g.drawText( tr[0] + 5, tr[1], deg );
               }
            }
         } else {
            g.pen = new Pen( 0xff888888 );
            g.drawText( 20, Math.round(vh/2), "Select a reference image above." );
         }

         g.end();
      };

      this.clampImg = function( v, max ) {
         return Math.max( 0, Math.min( v, max ) );
      };

      this.viewToImg = function( px, py ) {
         if ( !self.viewW || !self.viewH ) return new Point(0,0);
         return new Point(
            self.clampImg( px - self.viewX, self.viewW ),
            self.clampImg( py - self.viewY, self.viewH )
         );
      };

      var HIT = 10; // hit zone radius in display pixels

      this.hitTest = function( mx, my ) {
         if ( !self.selStart || !self.selEnd ) return "new";
         // Rotate handle -- same math as rotPt in onPaint
         var rx0c = Math.min(self.selStart.x,self.selEnd.x) + self.viewX;
         var rx1c = Math.max(self.selStart.x,self.selEnd.x) + self.viewX;
         var ry0c = Math.min(self.selStart.y,self.selEnd.y) + self.viewY;
         var ry1c = Math.max(self.selStart.y,self.selEnd.y) + self.viewY;
         if ( (rx1c - rx0c) > 10 ) {
            var scx2 = (rx0c + rx1c) / 2;
            var scy2 = (ry0c + ry1c) / 2;
            var hH2  = (ry1c - ry0c) / 2;
            var ca2  = Math.cos(self.angle), sa2 = Math.sin(self.angle);
            var lx2  = 0, ly2 = -hH2 - 20;
            var rotHx = scx2 + lx2*ca2 - ly2*sa2;
            var rotHy = scy2 + lx2*sa2 + ly2*ca2;
            if (Math.abs(mx-rotHx) <= 16 && Math.abs(my-rotHy) <= 16) return "rotate";
         }
         var rx0 = Math.min(self.selStart.x, self.selEnd.x) + self.viewX;
         var ry0 = Math.min(self.selStart.y, self.selEnd.y) + self.viewY;
         var rx1 = Math.max(self.selStart.x, self.selEnd.x) + self.viewX;
         var ry1 = Math.max(self.selStart.y, self.selEnd.y) + self.viewY;
         var inX  = mx >= rx0-HIT && mx <= rx1+HIT;
         var inY  = my >= ry0-HIT && my <= ry1+HIT;
         var onL  = Math.abs(mx-rx0) <= HIT;
         var onR  = Math.abs(mx-rx1) <= HIT;
         var onT  = Math.abs(my-ry0) <= HIT;
         var onB  = Math.abs(my-ry1) <= HIT;
         // Corners first
         if (onL && onT) return "corner-tl";
         if (onR && onT) return "corner-tr";
         if (onL && onB) return "corner-bl";
         if (onR && onB) return "corner-br";
         // Edges
         if (onL && inY) return "edge-l";
         if (onR && inY) return "edge-r";
         if (onT && inX) return "edge-t";
         if (onB && inX) return "edge-b";
         // Interior
         if (mx>=rx0 && mx<=rx1 && my>=ry0 && my<=ry1) return "move";
         return "new";
      };



      this.viewport.onMousePress = function( x, y, button, buttons, modifiers ) {
         if ( button !== MouseButton.Left ) return;
         var hit = self.hitTest(x, y);
         self.dragMode    = hit;
         self.dragAnchorX    = x;
         self.dragAnchorY    = y;
         self.dragAngleStart = self.angle;
         if ( hit === "rotate" && self.selStart && self.selEnd ) {
            self.rotateCenterX = (Math.min(self.selStart.x,self.selEnd.x) + Math.max(self.selStart.x,self.selEnd.x)) / 2 + self.viewX;
            self.rotateCenterY = (Math.min(self.selStart.y,self.selEnd.y) + Math.max(self.selStart.y,self.selEnd.y)) / 2 + self.viewY;
            self.rotateStartMouseAngle = Math.atan2(y - self.rotateCenterY, x - self.rotateCenterX);
            self.rotateStartImageAngle = self.angle;
         }
         self.dragSelSnapshot = (self.selStart && self.selEnd) ? {
            x0: Math.min(self.selStart.x,self.selEnd.x),
            y0: Math.min(self.selStart.y,self.selEnd.y),
            x1: Math.max(self.selStart.x,self.selEnd.x),
            y1: Math.max(self.selStart.y,self.selEnd.y)
         } : null;
         if ( hit === "new" ) {
            var p = self.viewToImg(x,y);
            self.selStart = p; self.selEnd = p;
            self.angle = 0.0;
         }
         self.viewport.update();
      };

      this.viewport.onMouseMove = function( x, y, buttons, modifiers ) {
         if ( self.dragMode === "none" ) {
               return;
         }
         // Center-based angular rotation -- true bidirectional
         if ( self.dragMode === "rotate" ) {
            var currentMouseAngle = Math.atan2(y - self.rotateCenterY, x - self.rotateCenterX);
            var delta = currentMouseAngle - self.rotateStartMouseAngle;
            while ( delta >  Math.PI ) delta -= 2*Math.PI;
            while ( delta < -Math.PI ) delta += 2*Math.PI;
            self.angle = self.rotateStartImageAngle + delta;
            while ( self.angle >  Math.PI ) self.angle -= 2*Math.PI;
            while ( self.angle < -Math.PI ) self.angle += 2*Math.PI;

            while ( self.angle >  Math.PI ) self.angle -= 2*Math.PI;
            while ( self.angle < -Math.PI ) self.angle += 2*Math.PI;
            self.viewport.update();
            if ( self.onSelectionChanged ) self.onSelectionChanged(false);
            return;
         }

         var dx = x - self.dragAnchorX;
         var dy = y - self.dragAnchorY;
         var s  = self.dragSelSnapshot;

         if ( self.dragMode === "new" ) {
            self.selEnd = self.viewToImg(x,y);
         } else if ( s ) {
            var ci = self.clampImg.bind(self);
            var W  = self.viewW, H = self.viewH;
            var x0=s.x0, y0=s.y0, x1=s.x1, y1=s.y1;
            if ( self.dragMode === "move" ) {
               var w=x1-x0, h=y1-y0;
               var nx0=ci(x0+dx,W-w), ny0=ci(y0+dy,H-h);
               self.selStart = new Point(nx0,ny0);
               self.selEnd   = new Point(ci(nx0+w,W),ci(ny0+h,H));
            } else if ( self.dragMode === "corner-tl" ) {
               self.selStart = new Point(ci(x0+dx,x1-2),ci(y0+dy,y1-2));
               self.selEnd   = new Point(x1,y1);
            } else if ( self.dragMode === "corner-tr" ) {
               self.selStart = new Point(x0,ci(y0+dy,y1-2));
               self.selEnd   = new Point(ci(x1+dx,W),y1);
            } else if ( self.dragMode === "corner-bl" ) {
               self.selStart = new Point(ci(x0+dx,x1-2),y0);
               self.selEnd   = new Point(x1,ci(y1+dy,H));
            } else if ( self.dragMode === "corner-br" ) {
               self.selStart = new Point(x0,y0);
               self.selEnd   = new Point(ci(x1+dx,W),ci(y1+dy,H));
            } else if ( self.dragMode === "edge-l" ) {
               self.selStart = new Point(ci(x0+dx,x1-2),y0);
               self.selEnd   = new Point(x1,y1);
            } else if ( self.dragMode === "edge-r" ) {
               self.selStart = new Point(x0,y0);
               self.selEnd   = new Point(ci(x1+dx,W),y1);
            } else if ( self.dragMode === "edge-t" ) {
               self.selStart = new Point(x0,ci(y0+dy,y1-2));
               self.selEnd   = new Point(x1,y1);
            } else if ( self.dragMode === "edge-b" ) {
               self.selStart = new Point(x0,y0);
               self.selEnd   = new Point(x1,ci(y1+dy,H));
            }
         }
         self.viewport.update();
         if ( self.onSelectionChanged ) self.onSelectionChanged(false);
      };

      this.viewport.onMouseRelease = function( x, y, button, buttons, modifiers ) {
         if ( button !== MouseButton.Left ) return;
         self.dragMode = "none";
         self.viewport.update();
         if ( self.onSelectionChanged ) self.onSelectionChanged(true);
      };

      this.getImageRect = function() {
         if ( !self.selStart || !self.selEnd ) {
            return null;
         }

         if ( !self.scaleX || !self.scaleY ) {
            return null;
         }

         var x0 = Math.round( Math.min( self.selStart.x, self.selEnd.x ) * self.scaleX );
         var y0 = Math.round( Math.min( self.selStart.y, self.selEnd.y ) * self.scaleY );
         var x1 = Math.round( Math.max( self.selStart.x, self.selEnd.x ) * self.scaleX );
         var y1 = Math.round( Math.max( self.selStart.y, self.selEnd.y ) * self.scaleY );

         x0 = Math.max( 0, Math.min( x0, self.imgWidth  ) );
         y0 = Math.max( 0, Math.min( y0, self.imgHeight ) );
         x1 = Math.max( 0, Math.min( x1, self.imgWidth  ) );
         y1 = Math.max( 0, Math.min( y1, self.imgHeight ) );

         if ( x1 - x0 < 2 || y1 - y0 < 2 ) {
            return null;
         }

         return new Rect( x0, y0, x1, y1 );
      };
   }
};

// ============================================================
// BatchCropDialog
// ============================================================
var BatchCropDialog = class BatchCropDialog extends Dialog {
   constructor() {
      super();

      this.windowTitle = SCRIPT_TITLE + " v" + SCRIPT_VERSION;

      var self = this;
      this.windows = ImageWindow.openWindows;

      if ( this.windows.length === 0 ) {
         new MessageBox(
            "No images are currently open.\nOpen your star-aligned images first.",
            SCRIPT_TITLE,
            StdIcon.Error,
            StdButton.Ok
         ).execute();

         this.cancel();
         return;
      }

      this.refLabel = new Label( this );
      this.refLabel.text = "Reference:";
      this.refLabel.minWidth = 70;

      this.refCombo = new ComboBox( this );

      for ( var i = 0; i < this.windows.length; ++i ) {
         this.refCombo.addItem( this.windows[i].mainView.id );
      }

      this.refCombo.currentItem = 0;
      this.refCombo.toolTip = "Choose the image to draw the crop region on.";
      this.refCombo.onItemSelected = function( idx ) {
         self.loadReference( idx );
      };

      this.stfButton = new PushButton( this );
      this.stfButton.text = "Auto STF";
      this.stfButton.toolTip = "Toggle auto-stretch display for linear images. Does not modify the source image.";
      this.stfButton.setFixedWidth( 100 );
      this._stfOn = false;

      this.stfButton.onClick = function() {
         self._stfOn = !self._stfOn;
         self.stfButton.text = self._stfOn ? "Auto STF ON" : "Auto STF";
         console.writeln( "BatchCrop: STF toggled " + (self._stfOn ? "ON" : "OFF") );
         self.preview.stfEnabled = self._stfOn;

         if ( self._stfOn ) {
            if ( !self.preview.linearBitmap ) {
               self.preview.linearBitmap = self.preview.sourceBitmap;
            }
            var refIdx = self.refCombo.currentItem;
            if ( self.windows && self.windows[refIdx] ) {
               self.preview.computeSTF( self.windows[refIdx] );
            }
         } else {
            if ( self.preview.linearBitmap ) {
               self.preview.sourceBitmap  = self.preview.linearBitmap;
               self.preview.linearBitmap  = null;
            }
            self.preview.displayBitmap = null;
            self.preview.stfLastState  = false;
            self.preview.viewport.update();
         }
      };

      var refSizer = new HorizontalSizer;
      refSizer.spacing = 6;
      refSizer.add( this.refLabel );
      refSizer.add( this.refCombo );
      refSizer.addStretch();
      refSizer.add( this.stfButton );

      this.preview = new CropPreviewControl( this );
      this.preview.setMinSize( 900, 600 );
      this.preview.onSelectionChanged = function( finished ) {
         self.updateCoordDisplay();
      };

      this.coordLabel = new Label( this );
      this.coordLabel.text = "Draw a crop rectangle on the image above.";

      this.applyButton = new PushButton( this );
      this.applyButton.text = " Apply to All Images ";
      this.applyButton.icon = this.scaledResource( ":/icons/ok.png" );
      this.applyButton.default = true;
      this.applyButton.onClick = function() {
         self.applyCrop();
      };


      this.helpButton = new PushButton( this );
      this.helpButton.text = " Help ";
      this.helpButton.icon = this.scaledResource( ":/icons/help.png" );
      this.helpButton.toolTip = "How to use Batch Crop.";
      this.helpButton.onClick = function() {
         var helpText = "Batch Crop v1.2 — Help\n\nOVERVIEW\nBatch Crop is designed for early in your processing workflow. It lets you draw a crop region on a reference image and apply that exact crop to every open image in PixInsight in one click.\n\nWHEN TO USE IT\nUse Batch Crop immediately after star alignment, before any processing. All images must have identical dimensions — they must be registered to the same frame. Use your stacking software's alignment output (APP, PixInsight StarAlignment) before opening them here.\n\nWORKFLOW\n1. Open all your aligned channel images in PixInsight (File > Open).\n2. Run Batch Crop from the Scripts menu under Utilities.\n3. Select a reference image from the dropdown (any channel works).\n4. Optionally click Auto STF to stretch the preview for easier viewing — this does not modify your images.\n5. Draw a crop rectangle by clicking and dragging on the preview.\n6. Adjust the selection:\n   — Drag corners to resize diagonally\n   — Drag edge midpoints to resize one side\n   — Drag inside the box to move it\n   — Drag the blue circle handle above the box to rotate\n   — Click Reset to clear and start over\n7. Click Apply to All Images to crop every open image.\n8. Use Edit > Undo in PixInsight to reverse the crop on any image.\n\nROTATION\nThe blue circle handle above the top edge of the selection rotates the crop box. Drag it left for counterclockwise, right for clockwise. The current angle is shown in the status bar and as an overlay on the box. Rotation uses PixInsight's DynamicCrop process, which supports arbitrary angles.\n\nDIMENSION MISMATCH\nIf any open image has different dimensions from the reference, Batch Crop will warn you and ask whether to skip it. This typically means that image was not aligned to the same reference frame. Star-align all images first using your stacking software or PixInsight's StarAlignment process.\n\nNOTES\n— Auto STF is display only. It never modifies your image data.\n— The original images are not modified until you click Apply to All Images.\n— Undo is available per image after applying.\n— Close intermediate working images checkbox removes the internal preview working copy when done.";
         var dlg = new Dialog;
         dlg.windowTitle = "Batch Crop v" + SCRIPT_VERSION + " — Help";
         dlg.userResizable = true;

         var textBox = new TextBox( dlg );
         textBox.text = helpText;
         textBox.readOnly = true;
         textBox.setMinSize( 560, 480 );

         var closeBtn = new PushButton( dlg );
         closeBtn.text = " Close ";
         closeBtn.icon = dlg.scaledResource( ":/icons/close.png" );
         closeBtn.onClick = function() { dlg.done(0); };

         var btnRow = new HorizontalSizer;
         btnRow.addStretch(); btnRow.add( closeBtn );

         dlg.sizer = new VerticalSizer;
         dlg.sizer.margin = 8; dlg.sizer.spacing = 6;
         dlg.sizer.add( textBox, 100 );
         dlg.sizer.add( btnRow );
         dlg.adjustToContents();
         dlg.execute();
      };

      this.cancelButton = new PushButton( this );
      this.cancelButton.text = " Cancel ";
      this.cancelButton.icon = this.scaledResource( ":/icons/cancel.png" );
      this.cancelButton.onClick = function() {
         self.cancel();
      };

      this.resetButton = new PushButton( this );
      this.resetButton.text = " Reset ";
      this.resetButton.icon = this.scaledResource( ":/icons/reload.png" );
      this.resetButton.toolTip = "Clear the crop selection.";
      this.resetButton.onClick = function() {
         self.preview.selStart    = null;
         self.preview.selEnd      = null;
         self.preview.dragMode    = "none";
         self.preview.angle       = 0.0;
         self.preview.viewport.update();
         self.updateCoordDisplay();
      };

      var btnSizer = new HorizontalSizer;
      btnSizer.spacing = 6;
      btnSizer.add( this.coordLabel );
      btnSizer.addStretch();
      btnSizer.add( this.helpButton );
      btnSizer.add( this.resetButton );
      btnSizer.add( this.cancelButton );
      btnSizer.add( this.applyButton );

      this.sizer = new VerticalSizer;
      this.sizer.margin = 8;
      this.sizer.spacing = 6;
      this.sizer.add( refSizer );
      this.sizer.add( this.preview, 100 );
      this.sizer.add( btnSizer );

      this.adjustToContents();
      this.setScaledMinSize( 940, 680 );
      this.loadReference( 0 );
   }

   loadReference( idx ) {
      this.preview.setImage( this.windows[idx] );
      this.updateCoordDisplay();
   }

   updateCoordDisplay() {
      function normalizeAnglePi( a ) {
         while ( a >  Math.PI ) a -= 2*Math.PI;
         while ( a < -Math.PI ) a += 2*Math.PI;
         return a;
      }
      var r = this.preview.getImageRect();

      if ( r ) {
         var deg = (normalizeAnglePi(this.preview.angle) * 180 / Math.PI).toFixed(1);
         this.coordLabel.text =
            "Selection:  x=" + r.x0 + "  y=" + r.y0 +
            "   →   " + r.x1 + " × " + r.y1 +
            "   (" + r.width + " × " + r.height + " px)" +
            (Math.abs(this.preview.angle) > 0.001 ? "   angle=" + deg + "°" : "");
      } else {
         this.coordLabel.text = "Draw a crop rectangle on the image above.";
      }
   }

   applyCrop() {
      var r = this.preview.getImageRect();

      if ( !r ) {
         new MessageBox(
            "Please draw a crop region first.",
            SCRIPT_TITLE,
            StdIcon.Error,
            StdButton.Ok
         ).execute();

         return;
      }

      var refIdx = this.refCombo.currentItem;
      var refImg = this.windows[refIdx].mainView.image;
      var W = refImg.width;
      var H = refImg.height;

      var leftMargin   = r.x0;
      var topMargin    = r.y0;
      var rightMargin  = W - r.x1;
      var bottomMargin = H - r.y1;

      Console.writeln(
         "<br><b>BatchCrop:</b> Selected keep rectangle: x0=" + r.x0 +
         " y0=" + r.y0 +
         " x1=" + r.x1 +
         " y1=" + r.y1 +
         " (" + r.width + "\u00d7" + r.height + " px)"
      );

      Console.writeln(
         "<b>BatchCrop:</b> Removing margins: left=" + leftMargin +
         " top=" + topMargin +
         " right=" + rightMargin +
         " bottom=" + bottomMargin
      );

      for ( var i = 0; i < this.windows.length; ++i ) {
         var img = this.windows[i].mainView.image;

         if ( img.width !== W || img.height !== H ) {
            var res = new MessageBox(
               "Image \"" + this.windows[i].mainView.id + "\" has different dimensions (" +
               img.width + "\u00d7" + img.height + ") than the reference (" +
               W + "\u00d7" + H + ").\n\nSkip this image and continue?",
               SCRIPT_TITLE + " \u2013 Dimension Mismatch",
               StdIcon.Warning,
               StdButton.Yes,
               StdButton.No
            ).execute();

            if ( res !== StdButton.Yes ) {
               return;
            }
         }
      }

      // Use DynamicCrop -- supports rotation, normalized parameters
      function normalizeAnglePi( a ) {
         while ( a >  Math.PI ) a -= 2*Math.PI;
         while ( a < -Math.PI ) a += 2*Math.PI;
         return a;
      }
      var dc = new DynamicCrop;
      dc.centerX = (r.x0 + r.width  / 2) / W;
      dc.centerY = (r.y0 + r.height / 2) / H;
      dc.width   = r.width  / W;
      dc.height  = r.height / H;
      dc.angle   = normalizeAnglePi( this.preview.angle || 0.0 );
      dc.scaleX  = 1.0;
      dc.scaleY  = 1.0;
      dc.noGUIMessages = true;

      var angleDeg = (dc.angle * 180 / Math.PI).toFixed(2);
      Console.writeln(
         "<b>BatchCrop:</b> DynamicCrop: cx=" + dc.centerX.toFixed(4) +
         " cy=" + dc.centerY.toFixed(4) +
         " w=" + dc.width.toFixed(4) +
         " h=" + dc.height.toFixed(4) +
         " angle=" + angleDeg + "°"
      );

      var count = 0;

      for ( var j = 0; j < this.windows.length; ++j ) {
         var win = this.windows[j];

         if (
            win.mainView.image.width  !== W ||
            win.mainView.image.height !== H
         ) {
            continue;
         }

         if ( !win.mainView.canWrite ) {
            Console.warningln(
               "Warning: view is read-only, attempting anyway: " +
               win.mainView.id
            );
         }

         dc.executeOn( win.mainView, true );
         ++count;
      }

      Console.writeln(
         "<br><b>BatchCrop:</b> Cropped " + count +
         " image(s) to " + r.width + "\u00d7" + r.height + " px."
      );

      this.ok();
   }
};

// ============================================================
// main
// ============================================================
function main() {
   Console.show();
   printSplash();


   Console.writeln( SCRIPT_TITLE + " v" + SCRIPT_VERSION );
   Console.writeln( "" );

   if ( !Parameters.isGlobalTarget && !Parameters.isViewTarget ) {
      var dlg = new BatchCropDialog();
      dlg.execute();
   }
}

main();